export interface Photo {
  id: string;
  url: string;
  title: string;
  category: 'portrait' | 'landscape' | 'wedding' | 'event';
  description?: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  price: string;
  features: string[];
}