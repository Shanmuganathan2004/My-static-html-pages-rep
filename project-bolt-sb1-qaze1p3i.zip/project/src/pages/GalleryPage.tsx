import React, { useState } from 'react';
import { Gallery } from '../components/Gallery';
import { photos } from '../data/photos';

export const GalleryPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();

  const categories = ['all', 'portrait', 'landscape', 'wedding', 'event'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-gray-900 mb-8">Photo Gallery</h1>
      
      <div className="flex space-x-4 mb-8">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category === 'all' ? undefined : category)}
            className={`px-4 py-2 rounded-md ${
              (category === 'all' && !selectedCategory) ||
              category === selectedCategory
                ? 'bg-black text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </button>
        ))}
      </div>

      <Gallery photos={photos} category={selectedCategory} />
    </div>
  );
};