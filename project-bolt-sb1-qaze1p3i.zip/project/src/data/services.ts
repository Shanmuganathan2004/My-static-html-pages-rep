import { Service } from '../types/gallery';

export const services: Service[] = [
  {
    id: '1',
    title: 'Wedding Photography',
    description: 'Capture your special day with stunning photography',
    price: 'From $1,500',
    features: [
      '8 hours coverage',
      'Professional editing',
      'Online gallery',
      'High-resolution images'
    ]
  },
  {
    id: '2',
    title: 'Portrait Session',
    description: 'Professional portrait photography for individuals or families',
    price: 'From $300',
    features: [
      '1-2 hour session',
      'Multiple outfit changes',
      'Professional editing',
      'Digital downloads'
    ]
  },
  // Add more services as needed
];