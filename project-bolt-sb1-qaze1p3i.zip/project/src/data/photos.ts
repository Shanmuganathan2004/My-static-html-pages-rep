import { Photo } from '../types/gallery';

export const photos: Photo[] = [
  {
    id: '1',
    url: 'https://images.unsplash.com/photo-1610047803562-7260ebe516cc',
    title: 'Mountain Sunset',
    category: 'landscape',
    description: 'Breathtaking sunset over mountain ranges'
  },
  {
    id: '2',
    url: 'https://images.unsplash.com/photo-1533106497176-45ae19e68ba2',
    title: 'Wedding Couple',
    category: 'wedding',
    description: 'Romantic wedding photoshoot'
  },
  {
    id: '3',
    url: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04',
    title: 'Portrait Study',
    category: 'portrait',
    description: 'Artistic portrait photography'
  },
  // Add more sample photos as needed
];