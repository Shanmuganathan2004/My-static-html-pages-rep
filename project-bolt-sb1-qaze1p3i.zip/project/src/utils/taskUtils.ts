import { v4 as uuidv4 } from 'uuid';
import { Task } from '../types/task';

export const createTask = (title: string, priority: Task['priority'] = 'medium'): Task => ({
  id: uuidv4(),
  title,
  completed: false,
  createdAt: new Date(),
  priority,
});

export const toggleTaskCompletion = (tasks: Task[], taskId: string): Task[] =>
  tasks.map((task) =>
    task.id === taskId ? { ...task, completed: !task.completed } : task
  );

export const deleteTask = (tasks: Task[], taskId: string): Task[] =>
  tasks.filter((task) => task.id !== taskId);