import React from 'react';
import Masonry from 'react-masonry-css';
import { motion } from 'framer-motion';
import { Photo } from '../types/gallery';

interface GalleryProps {
  photos: Photo[];
  category?: string;
}

export const Gallery: React.FC<GalleryProps> = ({ photos, category }) => {
  const filteredPhotos = category
    ? photos.filter((photo) => photo.category === category)
    : photos;

  const breakpointColumns = {
    default: 3,
    1100: 2,
    700: 1
  };

  return (
    <Masonry
      breakpointCols={breakpointColumns}
      className="flex -ml-4 w-auto"
      columnClassName="pl-4 bg-clip-padding"
    >
      {filteredPhotos.map((photo) => (
        <motion.div
          key={photo.id}
          className="mb-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="relative group">
            <img
              src={photo.url}
              alt={photo.title}
              className="w-full h-auto rounded-lg shadow-md"
            />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity duration-300 rounded-lg">
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="text-white text-center">
                  <h3 className="text-xl font-bold">{photo.title}</h3>
                  {photo.description && (
                    <p className="mt-2">{photo.description}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </Masonry>
  );
};