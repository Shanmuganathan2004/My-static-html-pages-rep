import React from 'react';
import { format } from 'date-fns';
import { CheckCircleIcon, TrashIcon } from '@heroicons/react/24/outline';
import { Task } from '../types/task';

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

const priorityColors = {
  low: 'bg-blue-100 text-blue-800',
  medium: 'bg-yellow-100 text-yellow-800',
  high: 'bg-red-100 text-red-800',
};

export const TaskItem: React.FC<TaskItemProps> = ({ task, onToggle, onDelete }) => {
  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center space-x-4">
        <button
          onClick={() => onToggle(task.id)}
          className={`p-1 rounded-full ${
            task.completed ? 'text-green-500' : 'text-gray-400'
          }`}
        >
          <CheckCircleIcon className="h-6 w-6" />
        </button>
        <div>
          <h3
            className={`text-lg font-medium ${
              task.completed ? 'line-through text-gray-400' : 'text-gray-700'
            }`}
          >
            {task.title}
          </h3>
          <div className="flex items-center space-x-2 mt-1">
            <span className="text-sm text-gray-500">
              {format(task.createdAt, 'MMM d, yyyy')}
            </span>
            <span
              className={`px-2 py-1 rounded-full text-xs font-medium ${
                priorityColors[task.priority]
              }`}
            >
              {task.priority}
            </span>
          </div>
        </div>
      </div>
      <button
        onClick={() => onDelete(task.id)}
        className="p-2 text-gray-400 hover:text-red-500 transition-colors"
      >
        <TrashIcon className="h-5 w-5" />
      </button>
    </div>
  );
};