import React from 'react';
import { Service } from '../types/gallery';
import { CheckCircleIcon } from '@heroicons/react/24/outline';

interface ServiceCardProps {
  service: Service;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="px-6 py-8">
        <h3 className="text-2xl font-bold text-gray-900">{service.title}</h3>
        <p className="mt-4 text-gray-500">{service.description}</p>
        <p className="mt-8 text-3xl font-bold text-gray-900">{service.price}</p>
        <ul className="mt-6 space-y-4">
          {service.features.map((feature, index) => (
            <li key={index} className="flex">
              <CheckCircleIcon className="flex-shrink-0 w-6 h-6 text-green-500" />
              <span className="ml-3 text-gray-500">{feature}</span>
            </li>
          ))}
        </ul>
        <button className="mt-8 w-full bg-black text-white py-3 px-6 rounded-md hover:bg-gray-800 transition-colors">
          Book Now
        </button>
      </div>
    </div>
  );
};